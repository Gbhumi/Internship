var abc = document.querySelector('#para');

function msg1() {
    abc.src = "images.jpeg";

};

function msg2() {
    abc.src = "cat4.png";

};